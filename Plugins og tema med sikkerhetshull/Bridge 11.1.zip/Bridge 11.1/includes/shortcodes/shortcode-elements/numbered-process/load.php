<?php

require_once QODE_SHORTCODES_ROOT_DIR.'/numbered-process/numbered-process.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/numbered-process/numbered-process-item.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/numbered-process/options-map/map.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/numbered-process/custom-styles/custom-styles.php';