<?php
class Element_DateTimeLocal extends Element_Textbox {
	protected $_attributes = array("type" => "datetime-local");
}
