<?php
/**
 * WP-JoomSport
 * @author      BearDev
 * @package     JoomSport
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<script src="<?php echo JOOMSPORT_LIVE_ASSETS;?>js/lightbox.js"></script>


