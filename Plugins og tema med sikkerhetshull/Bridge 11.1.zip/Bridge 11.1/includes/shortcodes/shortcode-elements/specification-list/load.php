<?php

require_once QODE_SHORTCODES_ROOT_DIR.'/specification-list/specification-list.php';