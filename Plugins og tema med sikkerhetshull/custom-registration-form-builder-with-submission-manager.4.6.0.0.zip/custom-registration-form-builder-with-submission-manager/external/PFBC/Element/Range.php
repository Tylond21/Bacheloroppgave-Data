<?php
class Element_Range extends Element_Textbox {
	protected $_attributes = array("type" => "range");
}
