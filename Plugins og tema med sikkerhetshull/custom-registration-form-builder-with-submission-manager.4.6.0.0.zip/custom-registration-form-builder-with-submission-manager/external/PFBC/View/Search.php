<?php
class View_Search extends View_Inline {
	protected $class = "form-search";
}	
