<?php

class RM_Chronos_Rule_SubTime extends RM_Chronos_Rule_Abstract {
    
    public function get_type() {
        return RM_Chronos_Rule_Interface::RULE_TYPE_SUB_TIME;
    }            
}


