<?php
/**
 * WP-JoomSport
 * @author      BearDev
 * @package     JoomSport
 */
class classExtrafieldText
{
    public static function getValue($ef)
    {
        return $ef;
    }
}
