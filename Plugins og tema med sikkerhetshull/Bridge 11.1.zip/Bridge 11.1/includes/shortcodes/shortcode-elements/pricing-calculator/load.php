<?php

require_once QODE_SHORTCODES_ROOT_DIR.'/pricing-calculator/pricing-calculator.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/pricing-calculator/pricing-calculator-functions.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/pricing-calculator/options-map/map.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/pricing-calculator/custom-styles/custom-styles.php';