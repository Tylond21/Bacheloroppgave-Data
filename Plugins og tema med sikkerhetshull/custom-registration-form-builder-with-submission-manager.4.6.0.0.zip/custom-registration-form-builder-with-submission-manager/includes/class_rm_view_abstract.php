<?php


Interface RM_View{
    public function set_view();
}