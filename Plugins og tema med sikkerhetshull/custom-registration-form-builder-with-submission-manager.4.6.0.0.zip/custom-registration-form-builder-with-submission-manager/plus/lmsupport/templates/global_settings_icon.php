<a href="admin.php?page=rm_ex_lmsupport">
    <div class="rm-settings-box">
        <img class="rm-settings-icon" src="<?php echo RM_EX_LMS()->base_url; ?>images/gs_icon.png">
        <div class="rm-settings-description">

        </div>
        <div class="rm-settings-subtitle"><?php echo RM_LMS_UI_Strings::get("LABEL_RM_GLOBAL_SETTING_MENU"); ?></div>
        <span><?php echo RM_LMS_UI_Strings::get("SUBTITLE_RM_GLOBAL_SETTING_MENU"); ?></span>
    </div>
</a>

